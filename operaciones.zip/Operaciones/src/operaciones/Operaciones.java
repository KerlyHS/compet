
package operaciones;


public class Operaciones {

    
    public static void main(String[] args) {
        int numero1 = 6;
        int numero2 = 7;
        
        int suma = numero1 + numero2;
        int resta = numero1 - numero2;
        int multiplicacion = numero1 * numero2;
        double division = (double)numero1 / (double)numero2;
                
        
        System.out.println("El resultado es: " + suma + "\nLa resta es: "+ resta + "\nLa multiplicacion es: " + multiplicacion + "\nLa division es: "+ division);
    }
    
}
